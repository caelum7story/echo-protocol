# ECHO — official Agent Mint guide

BNB Chain mainnet, chain ID **56**. The website reads live chain data; only the user's Agent and wallet sign participant transactions. No private key, login token, seed phrase, NFT approval or ERC-20 approval is required by this site.

## Current readiness

Read `/network.json` and `/agent.json` without caching. `integrationReady` means the integration is built; it is **not** permission to transact. Require `executionReady === true` **and** an independent on-chain read of `mintEnabled === true`, `paused === false`, `retired === false`, and `closed === false`. If any gate fails, return the state and stop. The deployment and owner activation are separate transactions. A prepared request is not a submitted or confirmed transaction.

Official deployment:

| Role | BNB Chain address |
| --- | --- |
| Mint / EchoLaunch | `0xe90D5BEb063B8df8c76AaF2B0da839cD4B19f55f` |
| ECHO token | `0xB3ca4b947872f92307bCB5b69Fb3a675ABfD8F41` |
| Oracle | `0xc5A4A7B12a889368379A01337d4639DfF99a57aD` |
| ECHO / WBNB pair | `0xaFe793901Ec2DAc8c8F5F832Ab818A0d06bC13CA` |
| Official .ai registry | `0x60b9262456de011f7d15a54cdd8c48baaa8b022f` |

Pin the runtime hashes from `/network.json` and `/deployment.mjs`, including registry and DEX references. Verify the Mint token, oracle, pair, identity and router bindings, and the token controller. `/abi/EchoLaunch.json`, `/abi/EchoToken.json` and `/abi/EchoOracle.json` are the exact compiled ABIs.

## Read-only CLI

Download `/agent/echo-agent.zip`. Check its SHA-256 against `cliArchiveSha256` in `/agent.json`, then unpack it preserving paths. It runs with Node 22+ and bundled ethers 6.17.0; no package installation or key is needed. This CLI **never signs or broadcasts**.

```text
node agent/echo-agent.mjs status
node agent/echo-agent.mjs identity --wallet <my-active-wallet>
node agent/echo-agent.mjs identity --name <my-official-handle>
node agent/echo-agent.mjs activity --name <my-official-handle>
node agent/echo-agent.mjs receipt --hash <real-transaction-hash>
```

Use the official `binance-agentic-wallet` skill to discover the user's active wallet and official Agent ID. Check Developer Mode and wallet controls through that skill before external signing. No website can pull native BNB from the wallet. Never ask a user to paste secrets into this site or a public conversation.

## Identity, referrals and quota

Normalize a handle with NFKC, remove zero-width characters, lowercase it, and remove one optional `.ai` suffix. It must contain 1–64 ASCII letters or digits. The official token ID is `uint256(keccak256(utf8(handle)))`. Read registry `ownerOf(identityId)` and `handleOf(owner)` and verify both against the user's active wallet. Never use an address, free-form name or mock record as identity proof. The [official SPACE ID reference](https://docs.space.id/agent-id.md) documents this registry.

Read `mintedById`, `successfulInvites`, `firstReferrer`, `freeClaimed`, `totalMinted`, `opened`, `pricingVersion` and `pricing` freshly. The base lifetime allowance is 10 shares per identity. Each distinct directly invited identity completing its first Mint adds one paid share. Self-referrals and referrals from the same wallet fail. A returning identity must use the `firstReferrer` already recorded by the contract; later referral links cannot replace it. A new identity may use the different registered identity in the user's original `ref=handle.ai` link. Do not silently remove an invalid referral.

Only an identity's first share may be free while the global pool of 1,000 free shares remains. Paid shares do not consume that pool. Every share counts toward the global 10,000-share cap. Each share delivers 1,000 ECHO in the successful Mint transaction. Network gas remains payable for free Mint.

## Exact quote and bounded transaction preparation

Show the user free shares, paid shares, exact Mint value and a separate maximum gas cost. Paid fallback requires prior consent binding **wallet, identity, shares, referrer, pricing version, phase, expiry, total Mint payment and gas cap**. Missing or exceeded consent stops preparation. Do not request unlimited spending authority. A changed pricing version or phase requires fresh consent; do not silently convert a pre-open consent into market-linked post-open consent.

Example command; replace placeholders only with the user's verified wallet, identity and explicit limits:

```text
node agent/echo-agent.mjs quote --name <handle> --shares <1-10> --wallet <wallet> --max-cost-wei <approved-Mint-cap> --gas-cap-wei <approved-gas-cap> --expected-version <version>
```

This reads `quote(wallet, identityId, shares, referrerId)`, builds `mint(MintParams)`, performs `eth_call` and gas estimation, and returns an **unsigned** transaction. Add `--referrer <handle>` only for the actual referral selected by the user; chain-recorded referrals override inbound links for returning identities. A free-only transaction uses `--max-cost-wei 0` when the user has not authorized any paid fallback.

`MintParams = { identityId, shares, referrerId, quoteHash: quote.stateHash, maxCost: approvedCap, deadline: latestBlock.timestamp + 300 }`.

Native `value` must equal the **fresh quote.cost**, not the cap. The contract TTL cannot exceed 600 seconds; this client uses 300. Refresh a stale quote within the same full bounded consent only when that consent still applies. Never automatically retry a submitted transaction: check its receipt, wallet pending transactions, identity mint count and nonce first. `PhaseBoundary(remaining)` requires reviewing a split at the pool-opening boundary. Excess payment is rejected, not refunded.

Use the official wallet skill's external-call preview. Its native value parameter is **wei**. Check exact chain, `from`, `to`, native value, decoded `mint` arguments, gas and quote expiry. Execute only after exact-transaction confirmation or an explicit, valid, bounded user instruction covering that transaction and permitted by wallet controls. Do not bypass that skill's preview, security or confirmation rules. The CLI's `broadcast:false` does not change until the wallet actually submits.

## Sale and market rules

The initial pre-open paid price is 0.002 BNB/share. Read `pricing` again because future Mint pricing can change. After pool opening, 1,000 ECHO/share remains fixed while BNB cost follows the contract's guarded market quote. The global cap is 10,000 shares. No overall Mint deadline and no Mint refunds. Successful paid Mint routes 70% of collected BNB to liquidity and 30% directly to the project. Free shares contribute no BNB. At 5,000 total shares including free claims, the pool opens automatically; the owner may open it earlier. Project LP is sent to the dead address. Mint continues after opening.

Immutable token transfer taxes: buy 1%, normal sell 2%; for the first 1,800 seconds **after pool opening**, sell tax is 30% **instead of** 2%. Tax tokens are accumulated and batch-swapped into BNB. DEX fees, price impact and gas are separate. There is no guaranteed return.

## Oracle maintenance after opening

The first paid quote after pool opening needs a healthy observation spanning at least 300 seconds. A keeper or any permitted wallet can call the public oracle `update()`. No funded automatic keeper is assumed. When `ORACLE_NOT_READY` occurs, explain the wait or required maintenance instead of inventing a price or signing a stale quote.

```text
node agent/echo-agent.mjs maintenance --gas-cap-wei <separately-approved-gas-cap>
```

The command only prepares an unsigned zero-value `update()` call. Before signing, bind it to the official oracle, simulate it, estimate gas and compare it with the separately approved cap through the wallet skill. If an observation is older than 3,600 seconds, one update restarts sampling; wait at least another 300 seconds and update again. Then request a new Mint quote. Excessive price deviation, insufficient liquidity or a stale observation pauses market-priced paid Mint. Tax processing is also permissionless through the launch contract and must not be silently bundled with a user's Mint consent.

## Confirm and share the real result

After actual wallet submission, return the real hash and query its receipt. Success requires receipt status 1, exactly the expected `Minted` event from the official launch contract, and the matching ECHO `Transfer` from the launch to the user's wallet in that transaction. Verify token amount, shares, payment, identity and recipient. A hash, pending transaction, CLI output or page message alone does not prove delivery. Report pending, failed and not-found states separately.

The CLI's `receipt` command verifies both event types. Return the public URL `https://echobsc.fun/?tx=<hash>#activity`. Only public identity names and transaction hashes belong in links. No sessions, login signatures, personal credentials, keys or seed phrases.

Activity is read directly from Mint events with paged block ranges and optional identity filtering. A returned `nextCursor` means earlier records remain; continue with `--before-block` and `--before-index`. An RPC failure is not proof of no activity.
